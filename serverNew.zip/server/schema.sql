-- ============================================================
-- School Attendance & Marks System — MySQL schema
-- ============================================================
-- Design notes:
--  * A "class" here means a form/grade group, e.g. S1, S2, S3, S4.
--  * A teacher is granted access to specific (subject, class) pairs
--    via teacher_subject_class — that is the core of the access
--    control: the server only ever lets a teacher see/edit students,
--    attendance, and marks for combinations listed in that table.
--  * A student "offers" a subject via student_subject — only students
--    enrolled in a subject show up for that subject's teacher.
--  * Marks have a status (DRAFT / CONFIRMED) so a teacher can enter and
--    revise a mark freely, then lock it in with a confirm action.
--    Editing a CONFIRMED mark requires an explicit unlock (admin, or
--    the owning teacher, depending on how you configure the API).
-- ============================================================

CREATE DATABASE IF NOT EXISTS school_system CHARACTER SET utf8mb4;
USE school_system;

-- ---------------------------------------------------------------
-- Users & roles
-- ---------------------------------------------------------------
CREATE TABLE users (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    username        VARCHAR(50)  NOT NULL UNIQUE,
    password_hash   VARCHAR(255) NOT NULL,
    full_name       VARCHAR(120) NOT NULL,
    role            ENUM('ADMIN', 'TEACHER') NOT NULL,
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Extra teacher-specific info, 1:1 with users where role = TEACHER
CREATE TABLE teachers (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    user_id         INT NOT NULL UNIQUE,
    staff_no        VARCHAR(30),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------
-- Academic structure
-- ---------------------------------------------------------------
CREATE TABLE classes (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    name            VARCHAR(20) NOT NULL UNIQUE   -- e.g. S1, S2, S3, S4
) ENGINE=InnoDB;

CREATE TABLE subjects (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    name            VARCHAR(50) NOT NULL UNIQUE,  -- English, Math, Geography, ...
    code            VARCHAR(10) UNIQUE
) ENGINE=InnoDB;

CREATE TABLE terms (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    name            VARCHAR(30) NOT NULL,         -- e.g. "Term 1 2026"
    year            INT NOT NULL,
    is_current      BOOLEAN NOT NULL DEFAULT FALSE
) ENGINE=InnoDB;

CREATE TABLE students (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    admission_no    VARCHAR(30) NOT NULL UNIQUE,
    full_name       VARCHAR(120) NOT NULL,
    class_id        INT NOT NULL,
    status          ENUM('ACTIVE', 'GRADUATED', 'TRANSFERRED', 'DROPPED') NOT NULL DEFAULT 'ACTIVE',
    FOREIGN KEY (class_id) REFERENCES classes(id)
) ENGINE=InnoDB;

-- Records one "Run promotion" click. Only the single most recent
-- non-undone batch can be undone (see /students/promote/undo/<id>),
-- to avoid unwinding a batch that a later promotion has already
-- built on top of.
CREATE TABLE promotion_batches (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    from_class_id   INT NOT NULL,
    to_class_id     INT NULL,               -- NULL when graduate = TRUE
    graduate        BOOLEAN NOT NULL DEFAULT FALSE,
    admin_user_id   INT NOT NULL,
    executed_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    undone          BOOLEAN NOT NULL DEFAULT FALSE,
    FOREIGN KEY (from_class_id) REFERENCES classes(id),
    FOREIGN KEY (to_class_id) REFERENCES classes(id),
    FOREIGN KEY (admin_user_id) REFERENCES users(id)
) ENGINE=InnoDB;

-- Per-student snapshot of class_id/status right before a promotion
-- batch touched them, so undo can restore it exactly.
CREATE TABLE promotion_batch_students (
    id                  INT AUTO_INCREMENT PRIMARY KEY,
    batch_id            INT NOT NULL,
    student_id          INT NOT NULL,
    previous_class_id   INT NOT NULL,
    previous_status     VARCHAR(20) NOT NULL,
    FOREIGN KEY (batch_id) REFERENCES promotion_batches(id) ON DELETE CASCADE,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Which subjects a student is enrolled in ("offering")
CREATE TABLE student_subject (
    student_id      INT NOT NULL,
    subject_id      INT NOT NULL,
    PRIMARY KEY (student_id, subject_id),
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- The core access-control table: which teacher teaches which subject
-- in which class. A teacher only ever sees data for rows that exist here.
CREATE TABLE teacher_subject_class (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    teacher_id      INT NOT NULL,
    subject_id      INT NOT NULL,
    class_id        INT NOT NULL,
    UNIQUE KEY uniq_assignment (teacher_id, subject_id, class_id),
    FOREIGN KEY (teacher_id) REFERENCES teachers(id) ON DELETE CASCADE,
    FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE,
    FOREIGN KEY (class_id) REFERENCES classes(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------
-- Attendance
-- ---------------------------------------------------------------
-- One row per student, per subject lesson, per date. Recorded by
-- whichever teacher owns that (subject, class) assignment.
--
-- NOTE: class_id here is a SNAPSHOT of the student's class at the time
-- the record was made — it is not re-derived from students.class_id.
-- This is what makes year-end promotion safe: promoting a student to
-- the next class only changes students.class_id going forward; every
-- attendance/mark row already on file keeps the class it actually
-- happened in.
CREATE TABLE attendance (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    student_id      INT NOT NULL,
    subject_id      INT NOT NULL,
    class_id        INT NOT NULL,
    teacher_id      INT NOT NULL,
    term_id         INT NOT NULL,
    attendance_date DATE NOT NULL,
    status          ENUM('PRESENT', 'ABSENT') NOT NULL,
    recorded_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_attendance (student_id, subject_id, class_id, attendance_date),
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (subject_id) REFERENCES subjects(id),
    FOREIGN KEY (class_id) REFERENCES classes(id),
    FOREIGN KEY (teacher_id) REFERENCES teachers(id),
    FOREIGN KEY (term_id) REFERENCES terms(id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------
-- Marks
-- ---------------------------------------------------------------
-- One mark per student, per subject, per term, per exam sitting.
-- Every term has three sittings: BEGINNING, MID, and END of term.
CREATE TABLE marks (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    student_id      INT NOT NULL,
    subject_id      INT NOT NULL,
    class_id        INT NOT NULL,
    term_id         INT NOT NULL,
    teacher_id      INT NOT NULL,
    exam_type       ENUM('BEGINNING', 'MID', 'END') NOT NULL,
    score           DECIMAL(5,2) NOT NULL,   -- e.g. out of 100
    status          ENUM('DRAFT', 'CONFIRMED') NOT NULL DEFAULT 'DRAFT',
    confirmed_at    TIMESTAMP NULL,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_mark (student_id, subject_id, term_id, exam_type),
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (subject_id) REFERENCES subjects(id),
    FOREIGN KEY (class_id) REFERENCES classes(id),
    FOREIGN KEY (teacher_id) REFERENCES teachers(id),
    FOREIGN KEY (term_id) REFERENCES terms(id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------
-- Seed data: the 10 subjects and 4 classes mentioned in the spec.
-- ---------------------------------------------------------------
INSERT INTO subjects (name, code) VALUES
    ('English', 'ENG'), ('Mathematics', 'MATH'), ('Geography', 'GEO'),
    ('Chemistry', 'CHEM'), ('Physics', 'PHY'), ('Biology', 'BIO'),
    ('History', 'HIST'), ('Computer Studies', 'COMP'),
    ('French', 'FRE'), ('CRE', 'CRE');

INSERT INTO classes (name) VALUES ('S1'), ('S2'), ('S3'), ('S4');

INSERT INTO terms (name, year, is_current) VALUES ('Term 1', YEAR(CURDATE()), TRUE);

-- Default admin login: username "admin", password "admin123"
-- (bcrypt hash generated by the app on first run — see server/create_admin.py)
