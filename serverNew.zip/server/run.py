from app import create_app

app = create_app()

if __name__ == "__main__":
    # 0.0.0.0 so devices on the school's LAN (running the Kivy app) can reach it.
    app.run(host="0.0.0.0", port=5000, debug=True)
