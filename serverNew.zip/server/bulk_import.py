"""
Bulk-import an existing school's teachers, students, and subject
assignments from CSV files. Meant to be run once during setup, directly
against the database (no need for the server to be running).

Usage:
    python bulk_import.py teachers    sample_csv/teachers.csv
    python bulk_import.py students    sample_csv/students.csv
    python bulk_import.py assignments sample_csv/assignments.csv

Run them in that order — students reference classes (already seeded),
and assignments reference both teachers and students' classes/subjects.

Already-existing records (matched by username / admission_no / the
teacher+subject+class combo) are skipped, so it's safe to re-run a file
after fixing a few rows.

See sample_csv/ for example files and the exact column names expected.
"""
import sys
import csv

from werkzeug.security import generate_password_hash
from app import create_app
from app.models import db, User, Teacher, Student, SchoolClass, Subject, TeacherSubjectClass

app = create_app()


def import_teachers(path):
    with app.app_context():
        created, skipped = 0, 0
        with open(path, newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                username = row["username"].strip()
                if User.query.filter_by(username=username).first():
                    print(f"  skip {username}: already exists")
                    skipped += 1
                    continue

                user = User(
                    username=username,
                    password_hash=generate_password_hash(row["password"].strip()),
                    full_name=row["full_name"].strip(),
                    role="TEACHER",
                )
                db.session.add(user)
                db.session.flush()  # need user.id before creating the Teacher row
                db.session.add(Teacher(user_id=user.id, staff_no=row.get("staff_no", "").strip()))
                created += 1
                print(f"  created teacher {username} ({row['full_name'].strip()})")

        db.session.commit()
        print(f"\nTeachers: {created} created, {skipped} skipped")


def import_students(path):
    with app.app_context():
        created, skipped = 0, 0
        with open(path, newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                admission_no = row["admission_no"].strip()
                if Student.query.filter_by(admission_no=admission_no).first():
                    print(f"  skip {admission_no}: already exists")
                    skipped += 1
                    continue

                class_name = row["class_name"].strip()
                cls = SchoolClass.query.filter_by(name=class_name).first()
                if not cls:
                    print(f"  skip {admission_no}: unknown class '{class_name}'")
                    skipped += 1
                    continue

                student = Student(
                    admission_no=admission_no,
                    full_name=row["full_name"].strip(),
                    class_id=cls.id,
                )

                # subjects column is semicolon-separated, e.g. "English;Mathematics;Biology"
                subject_names = [s.strip() for s in row.get("subjects", "").split(";") if s.strip()]
                if subject_names:
                    matched = Subject.query.filter(Subject.name.in_(subject_names)).all()
                    matched_names = {s.name for s in matched}
                    for missing in set(subject_names) - matched_names:
                        print(f"  warning: subject '{missing}' not found for {admission_no}, skipping that subject")
                    student.subjects = matched

                db.session.add(student)
                created += 1
                print(f"  created student {admission_no} ({row['full_name'].strip()}) in {class_name}")

        db.session.commit()
        print(f"\nStudents: {created} created, {skipped} skipped")


def import_assignments(path):
    with app.app_context():
        created, skipped = 0, 0
        with open(path, newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                username = row["teacher_username"].strip()
                subject_name = row["subject_name"].strip()
                class_name = row["class_name"].strip()

                user = User.query.filter_by(username=username).first()
                if not user or not user.teacher:
                    print(f"  skip: unknown teacher username '{username}'")
                    skipped += 1
                    continue

                subject = Subject.query.filter_by(name=subject_name).first()
                cls = SchoolClass.query.filter_by(name=class_name).first()
                if not subject or not cls:
                    print(f"  skip: unknown subject '{subject_name}' or class '{class_name}'")
                    skipped += 1
                    continue

                exists = TeacherSubjectClass.query.filter_by(
                    teacher_id=user.teacher.id, subject_id=subject.id, class_id=cls.id
                ).first()
                if exists:
                    skipped += 1
                    continue

                db.session.add(TeacherSubjectClass(
                    teacher_id=user.teacher.id, subject_id=subject.id, class_id=cls.id
                ))
                created += 1
                print(f"  assigned {username} -> {subject_name} / {class_name}")

        db.session.commit()
        print(f"\nAssignments: {created} created, {skipped} skipped")


COMMANDS = {"teachers": import_teachers, "students": import_students, "assignments": import_assignments}

if __name__ == "__main__":
    if len(sys.argv) != 3 or sys.argv[1] not in COMMANDS:
        print(__doc__)
        sys.exit(1)
    COMMANDS[sys.argv[1]](sys.argv[2])
