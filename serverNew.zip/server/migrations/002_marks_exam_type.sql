-- ============================================================
-- Migration: split each term's single mark per student/subject into
-- three sittings — BEGINNING, MID, and END of term — via a new
-- exam_type column, and widen the unique key to match.
--
-- Only run this if your database was created before this migration
-- was added.
--
-- NOTE: any marks already recorded under the old one-mark-per-term
-- model are assumed to be END-of-term marks (the most common single
-- sitting), so existing data isn't lost. Adjust the UPDATE below
-- first if that assumption is wrong for your data.
-- ============================================================
USE school_system;

ALTER TABLE marks
    ADD COLUMN exam_type ENUM('BEGINNING', 'MID', 'END')
        NOT NULL DEFAULT 'END' AFTER teacher_id;

ALTER TABLE marks DROP INDEX uniq_mark;
ALTER TABLE marks ADD UNIQUE KEY uniq_mark (student_id, subject_id, term_id, exam_type);

-- Drop the default now that existing rows are backfilled — new rows
-- must specify exam_type explicitly.
ALTER TABLE marks ALTER COLUMN exam_type DROP DEFAULT;
