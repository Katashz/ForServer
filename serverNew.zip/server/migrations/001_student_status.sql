-- ============================================================
-- Migration: replace students.is_active (boolean) with a proper
-- status enum, so a student can be ACTIVE, GRADUATED (finished S4),
-- TRANSFERRED (left for another school), or DROPPED.
--
-- Only run this if your database was created before this migration
-- was added. Safe to run once; re-running will error harmlessly on
-- the ADD COLUMN step (column already exists).
-- ============================================================
USE school_system;

ALTER TABLE students
    ADD COLUMN status ENUM('ACTIVE', 'GRADUATED', 'TRANSFERRED', 'DROPPED')
        NOT NULL DEFAULT 'ACTIVE' AFTER class_id;

UPDATE students SET status = IF(is_active, 'ACTIVE', 'DROPPED');

ALTER TABLE students DROP COLUMN is_active;
