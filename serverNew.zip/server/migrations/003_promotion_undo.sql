-- ============================================================
-- Migration: add promotion_batches / promotion_batch_students, so
-- year-end promotion can be undone. Every "Run promotion" click now
-- logs a batch plus each affected student's previous class_id/status;
-- undo restores exactly that.
--
-- Only run this if your database was created before this migration
-- was added.
-- ============================================================
USE school_system;

CREATE TABLE promotion_batches (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    from_class_id   INT NOT NULL,
    to_class_id     INT NULL,
    graduate        BOOLEAN NOT NULL DEFAULT FALSE,
    admin_user_id   INT NOT NULL,
    executed_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    undone          BOOLEAN NOT NULL DEFAULT FALSE,
    FOREIGN KEY (from_class_id) REFERENCES classes(id),
    FOREIGN KEY (to_class_id) REFERENCES classes(id),
    FOREIGN KEY (admin_user_id) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE promotion_batch_students (
    id                  INT AUTO_INCREMENT PRIMARY KEY,
    batch_id            INT NOT NULL,
    student_id          INT NOT NULL,
    previous_class_id   INT NOT NULL,
    previous_status     VARCHAR(20) NOT NULL,
    FOREIGN KEY (batch_id) REFERENCES promotion_batches(id) ON DELETE CASCADE,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
) ENGINE=InnoDB;
