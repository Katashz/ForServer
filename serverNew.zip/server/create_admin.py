"""
Run once after setting up the database to create the first admin login:
    python create_admin.py
"""
from werkzeug.security import generate_password_hash
from app import create_app
from app.models import db, User

app = create_app()

with app.app_context():
    username = input("Admin username [admin]: ").strip() or "admin"
    password = input("Admin password: ").strip()
    full_name = input("Full name [System Administrator]: ").strip() or "System Administrator"

    if User.query.filter_by(username=username).first():
        print(f"User '{username}' already exists.")
    else:
        user = User(
            username=username,
            password_hash=generate_password_hash(password),
            full_name=full_name,
            role="ADMIN"
        )
        db.session.add(user)
        db.session.commit()
        print(f"Admin user '{username}' created.")
