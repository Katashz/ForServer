import jwt
import datetime
from functools import wraps
from flask import request, jsonify, current_app, g

from app.models import Teacher, TeacherSubjectClass, Student


def generate_token(user):
    payload = {
        "user_id": user.id,
        "role": user.role,
        "teacher_id": user.teacher.id if user.teacher else None,
        "exp": datetime.datetime.utcnow()
        + datetime.timedelta(hours=current_app.config["JWT_EXPIRY_HOURS"]),
    }
    return jwt.encode(payload, current_app.config["JWT_SECRET"], algorithm="HS256")


def decode_token(token):
    return jwt.decode(token, current_app.config["JWT_SECRET"], algorithms=["HS256"])


def login_required(f):
    """Attaches the decoded token payload to `g.user` if valid."""
    @wraps(f)
    def wrapper(*args, **kwargs):
        auth_header = request.headers.get("Authorization", "")
        if not auth_header.startswith("Bearer "):
            return jsonify({"error": "Missing or invalid Authorization header"}), 401
        token = auth_header.split(" ", 1)[1]
        try:
            g.user = decode_token(token)
        except jwt.ExpiredSignatureError:
            return jsonify({"error": "Token expired, please log in again"}), 401
        except jwt.InvalidTokenError:
            return jsonify({"error": "Invalid token"}), 401
        return f(*args, **kwargs)
    return wrapper


def admin_required(f):
    @wraps(f)
    @login_required
    def wrapper(*args, **kwargs):
        if g.user["role"] != "ADMIN":
            return jsonify({"error": "Admin access required"}), 403
        return f(*args, **kwargs)
    return wrapper


def teacher_required(f):
    @wraps(f)
    @login_required
    def wrapper(*args, **kwargs):
        if g.user["role"] != "TEACHER":
            return jsonify({"error": "Teacher access required"}), 403
        return f(*args, **kwargs)
    return wrapper


def teacher_has_access(teacher_id: int, subject_id: int, class_id: int) -> bool:
    """
    The single source of truth for the access-control rule:
    a teacher may only act on a (subject, class) pair they are assigned to.
    Every teacher-facing endpoint that touches students/attendance/marks
    must call this before reading or writing anything.
    """
    return (
        TeacherSubjectClass.query.filter_by(
            teacher_id=teacher_id, subject_id=subject_id, class_id=class_id
        ).first()
        is not None
    )


def student_is_valid_for(student_id: int, subject_id: int, class_id: int) -> bool:
    """
    Companion check to teacher_has_access(): confirms the *student* actually
    belongs on this roster — i.e. they are ACTIVE, currently in this class,
    and enrolled ("offering") this subject.

    teacher_has_access() alone only proves the teacher owns the (subject,
    class) combo; without this, a teacher could still submit attendance or
    a mark for an arbitrary student_id that has nothing to do with that
    combo (wrong class, or a student who doesn't take the subject). Every
    write endpoint that accepts a student_id must call both checks.
    """
    student = Student.query.get(student_id)
    if student is None:
        return False
    if student.status != "ACTIVE":
        return False
    if student.class_id != class_id:
        return False
    return any(s.id == subject_id for s in student.subjects)
