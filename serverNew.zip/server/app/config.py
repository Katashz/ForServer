import os

class Config:
    # Update these to match your MySQL server before running.
    MYSQL_HOST = os.environ.get("MYSQL_HOST", "localhost")
    MYSQL_USER = os.environ.get("MYSQL_USER", "school_app")
    MYSQL_PASSWORD = os.environ.get("MYSQL_PASSWORD", "change_this_password")
    MYSQL_DB = os.environ.get("MYSQL_DB", "school_system")

    SQLALCHEMY_DATABASE_URI = (
        f"mysql+pymysql://{MYSQL_USER}:{MYSQL_PASSWORD}@{MYSQL_HOST}/{MYSQL_DB}"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # Change this to a long random string in production (e.g. `openssl rand -hex 32`)
    JWT_SECRET = os.environ.get("JWT_SECRET", "change-this-secret-key")
    JWT_EXPIRY_HOURS = 12
