from datetime import datetime, date
from flask import Blueprint, request, jsonify, g

from app.models import db, TeacherSubjectClass, Student, Attendance, Mark, Term
from app.auth import teacher_required, teacher_has_access, student_is_valid_for

teacher_bp = Blueprint("teacher", __name__)

EXAM_TYPES = ("BEGINNING", "MID", "END")


def _current_term():
    return Term.query.filter_by(is_current=True).first()


# ---------------------------------------------------------------
# What this teacher is allowed to teach
# ---------------------------------------------------------------
@teacher_bp.route("/my-assignments", methods=["GET"])
@teacher_required
def my_assignments():
    teacher_id = g.user["teacher_id"]
    assignments = TeacherSubjectClass.query.filter_by(teacher_id=teacher_id).all()
    return jsonify([
        {
            "assignment_id": a.id,
            "subject_id": a.subject_id, "subject_name": a.subject.name,
            "class_id": a.class_id, "class_name": a.school_class.name
        }
        for a in assignments
    ])


# ---------------------------------------------------------------
# Students in one of this teacher's (subject, class) combos
# ---------------------------------------------------------------
@teacher_bp.route("/students", methods=["GET"])
@teacher_required
def students_for_assignment():
    teacher_id = g.user["teacher_id"]
    subject_id = request.args.get("subject_id", type=int)
    class_id = request.args.get("class_id", type=int)

    if not subject_id or not class_id:
        return jsonify({"error": "subject_id and class_id are required"}), 400
    if not teacher_has_access(teacher_id, subject_id, class_id):
        return jsonify({"error": "You are not assigned to this subject/class"}), 403

    # Only students in that class who are also enrolled ("offering") the subject
    students = (
        Student.query.filter_by(class_id=class_id, status="ACTIVE")
        .filter(Student.subjects.any(id=subject_id))
        .order_by(Student.full_name)
        .all()
    )
    return jsonify([
        {"id": s.id, "admission_no": s.admission_no, "full_name": s.full_name}
        for s in students
    ])


# ---------------------------------------------------------------
# Attendance
# ---------------------------------------------------------------
@teacher_bp.route("/attendance", methods=["GET"])
@teacher_required
def get_attendance():
    """Fetch existing attendance for a subject/class/date, so the app can
    pre-fill the marking screen if it was already recorded."""
    teacher_id = g.user["teacher_id"]
    subject_id = request.args.get("subject_id", type=int)
    class_id = request.args.get("class_id", type=int)
    the_date = request.args.get("date")  # YYYY-MM-DD

    if not all([subject_id, class_id, the_date]):
        return jsonify({"error": "subject_id, class_id, date are required"}), 400
    if not teacher_has_access(teacher_id, subject_id, class_id):
        return jsonify({"error": "You are not assigned to this subject/class"}), 403

    records = Attendance.query.filter_by(
        subject_id=subject_id, class_id=class_id, attendance_date=the_date
    ).all()
    return jsonify([{"student_id": r.student_id, "status": r.status} for r in records])


@teacher_bp.route("/attendance", methods=["POST"])
@teacher_required
def submit_attendance():
    """
    Body: {
      "subject_id": 1, "class_id": 2, "date": "2026-07-15",
      "records": [{"student_id": 10, "status": "PRESENT"}, ...]
    }
    Upserts one row per student for that subject/class/date.
    """
    teacher_id = g.user["teacher_id"]
    data = request.json or {}
    subject_id = data.get("subject_id")
    class_id = data.get("class_id")
    the_date = data.get("date")
    records = data.get("records", [])

    if not all([subject_id, class_id, the_date]) or not records:
        return jsonify({"error": "subject_id, class_id, date, records are required"}), 400
    if not teacher_has_access(teacher_id, subject_id, class_id):
        return jsonify({"error": "You are not assigned to this subject/class"}), 403

    term = _current_term()
    if not term:
        return jsonify({"error": "No current term is set. Ask an admin to set one."}), 400

    saved, rejected = 0, []

    for rec in records:
        student_id = rec.get("student_id")
        status = rec.get("status")
        if status not in ("PRESENT", "ABSENT"):
            continue

        # Confirms this student is ACTIVE, actually in class_id, and
        # enrolled in subject_id — teacher_has_access() above only proved
        # the teacher owns the combo, not that this student belongs to it.
        if not student_is_valid_for(student_id, subject_id, class_id):
            rejected.append(student_id)
            continue

        existing = Attendance.query.filter_by(
            student_id=student_id, subject_id=subject_id,
            class_id=class_id, attendance_date=the_date
        ).first()

        if existing:
            existing.status = status
            existing.teacher_id = teacher_id
        else:
            db.session.add(Attendance(
                student_id=student_id, subject_id=subject_id, class_id=class_id,
                teacher_id=teacher_id, term_id=term.id,
                attendance_date=the_date, status=status
            ))
        saved += 1

    db.session.commit()
    return jsonify({"saved": saved, "rejected_student_ids": rejected})


# ---------------------------------------------------------------
# Marks
# ---------------------------------------------------------------
@teacher_bp.route("/marks", methods=["GET"])
@teacher_required
def get_marks():
    teacher_id = g.user["teacher_id"]
    subject_id = request.args.get("subject_id", type=int)
    class_id = request.args.get("class_id", type=int)
    exam_type = request.args.get("exam_type")

    if not subject_id or not class_id:
        return jsonify({"error": "subject_id and class_id are required"}), 400
    if exam_type not in EXAM_TYPES:
        return jsonify({"error": f"exam_type must be one of {EXAM_TYPES}"}), 400
    if not teacher_has_access(teacher_id, subject_id, class_id):
        return jsonify({"error": "You are not assigned to this subject/class"}), 403

    term = _current_term()
    if not term:
        return jsonify({"error": "No current term is set. Ask an admin to set one."}), 400

    marks = Mark.query.filter_by(
        subject_id=subject_id, class_id=class_id, term_id=term.id, exam_type=exam_type
    ).all()
    return jsonify([
        {
            "id": m.id, "student_id": m.student_id, "score": float(m.score),
            "exam_type": m.exam_type, "status": m.status
        }
        for m in marks
    ])


@teacher_bp.route("/marks", methods=["POST"])
@teacher_required
def submit_mark():
    """Create or update a single student's DRAFT mark for one exam sitting
    (BEGINNING/MID/END of term). Editing a CONFIRMED mark is blocked here
    — use /marks/<id>/unlock (admin) first."""
    teacher_id = g.user["teacher_id"]
    data = request.json or {}
    student_id = data.get("student_id")
    subject_id = data.get("subject_id")
    class_id = data.get("class_id")
    exam_type = data.get("exam_type")
    score = data.get("score")

    if not all([student_id, subject_id, class_id, exam_type]) or score is None:
        return jsonify({
            "error": "student_id, subject_id, class_id, exam_type, score are required"
        }), 400
    if exam_type not in EXAM_TYPES:
        return jsonify({"error": f"exam_type must be one of {EXAM_TYPES}"}), 400
    if not teacher_has_access(teacher_id, subject_id, class_id):
        return jsonify({"error": "You are not assigned to this subject/class"}), 403
    if not student_is_valid_for(student_id, subject_id, class_id):
        return jsonify({
            "error": "This student is not an active enrollee of this subject/class"
        }), 400

    term = _current_term()
    if not term:
        return jsonify({"error": "No current term is set. Ask an admin to set one."}), 400

    mark = Mark.query.filter_by(
        student_id=student_id, subject_id=subject_id, term_id=term.id, exam_type=exam_type
    ).first()

    if mark and mark.status == "CONFIRMED":
        return jsonify({"error": "Mark is confirmed and locked. Ask an admin to unlock it."}), 409

    if mark:
        mark.score = score
        mark.teacher_id = teacher_id
    else:
        mark = Mark(
            student_id=student_id, subject_id=subject_id, class_id=class_id,
            term_id=term.id, teacher_id=teacher_id, exam_type=exam_type,
            score=score, status="DRAFT"
        )
        db.session.add(mark)

    db.session.commit()
    return jsonify({"id": mark.id, "exam_type": mark.exam_type, "status": mark.status})


@teacher_bp.route("/marks/<int:mark_id>/confirm", methods=["POST"])
@teacher_required
def confirm_mark(mark_id):
    teacher_id = g.user["teacher_id"]
    mark = Mark.query.get_or_404(mark_id)

    if not teacher_has_access(teacher_id, mark.subject_id, mark.class_id):
        return jsonify({"error": "You are not assigned to this subject/class"}), 403

    mark.status = "CONFIRMED"
    mark.confirmed_at = datetime.utcnow()
    db.session.commit()
    return jsonify({"id": mark.id, "status": mark.status})


@teacher_bp.route("/marks/confirm-batch", methods=["POST"])
@teacher_required
def confirm_marks_batch():
    """Confirm all of this teacher's DRAFT marks for one subject/class/exam
    sitting at once (e.g. lock in all MID-of-term marks for S2 Chemistry)."""
    teacher_id = g.user["teacher_id"]
    data = request.json or {}
    subject_id = data.get("subject_id")
    class_id = data.get("class_id")
    exam_type = data.get("exam_type")

    if not subject_id or not class_id or not exam_type:
        return jsonify({"error": "subject_id, class_id, exam_type are required"}), 400
    if exam_type not in EXAM_TYPES:
        return jsonify({"error": f"exam_type must be one of {EXAM_TYPES}"}), 400
    if not teacher_has_access(teacher_id, subject_id, class_id):
        return jsonify({"error": "You are not assigned to this subject/class"}), 403

    term = _current_term()
    if not term:
        return jsonify({"error": "No current term is set. Ask an admin to set one."}), 400

    marks = Mark.query.filter_by(
        subject_id=subject_id, class_id=class_id, term_id=term.id,
        exam_type=exam_type, status="DRAFT"
    ).all()
    for m in marks:
        m.status = "CONFIRMED"
        m.confirmed_at = datetime.utcnow()
    db.session.commit()
    return jsonify({"confirmed": len(marks)})
