from flask import Blueprint, request, jsonify
from werkzeug.security import check_password_hash

from app.models import User
from app.auth import generate_token

auth_bp = Blueprint("auth", __name__)


@auth_bp.route("/login", methods=["POST"])
def login():
    data = request.get_json(silent=True) or {}
    username = data.get("username", "").strip()
    password = data.get("password", "")

    if not username or not password:
        return jsonify({"error": "username and password are required"}), 400

    user = User.query.filter_by(username=username).first()
    if not user or not user.is_active or not check_password_hash(user.password_hash, password):
        return jsonify({"error": "Invalid username or password"}), 401

    token = generate_token(user)
    return jsonify({
        "token": token,
        "role": user.role,
        "full_name": user.full_name,
        "teacher_id": user.teacher.id if user.teacher else None
    })
