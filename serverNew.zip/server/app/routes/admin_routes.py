from flask import Blueprint, request, jsonify, g
from werkzeug.security import generate_password_hash

from app.models import (
    db, User, Teacher, SchoolClass, Subject, Term, Student, TeacherSubjectClass,
    PromotionBatch, PromotionBatchStudent
)
from app.auth import admin_required

admin_bp = Blueprint("admin", __name__)


# ---------------------------------------------------------------
# Classes
# ---------------------------------------------------------------
@admin_bp.route("/classes", methods=["GET"])
@admin_required
def list_classes():
    return jsonify([{"id": c.id, "name": c.name} for c in SchoolClass.query.all()])


@admin_bp.route("/classes", methods=["POST"])
@admin_required
def create_class():
    name = (request.json or {}).get("name", "").strip()
    if not name:
        return jsonify({"error": "name is required"}), 400
    c = SchoolClass(name=name)
    db.session.add(c)
    db.session.commit()
    return jsonify({"id": c.id, "name": c.name}), 201


# ---------------------------------------------------------------
# Subjects
# ---------------------------------------------------------------
@admin_bp.route("/subjects", methods=["GET"])
@admin_required
def list_subjects():
    return jsonify([{"id": s.id, "name": s.name, "code": s.code} for s in Subject.query.all()])


@admin_bp.route("/subjects", methods=["POST"])
@admin_required
def create_subject():
    data = request.json or {}
    name = data.get("name", "").strip()
    if not name:
        return jsonify({"error": "name is required"}), 400
    s = Subject(name=name, code=data.get("code"))
    db.session.add(s)
    db.session.commit()
    return jsonify({"id": s.id, "name": s.name, "code": s.code}), 201


# ---------------------------------------------------------------
# Terms
# ---------------------------------------------------------------
@admin_bp.route("/terms", methods=["GET"])
@admin_required
def list_terms():
    return jsonify([
        {"id": t.id, "name": t.name, "year": t.year, "is_current": t.is_current}
        for t in Term.query.all()
    ])


@admin_bp.route("/terms", methods=["POST"])
@admin_required
def create_term():
    data = request.json or {}
    name = data.get("name", "").strip()
    year = data.get("year")
    if not name or not year:
        return jsonify({"error": "name and year are required"}), 400

    if data.get("is_current"):
        Term.query.update({Term.is_current: False})

    t = Term(name=name, year=year, is_current=bool(data.get("is_current", False)))
    db.session.add(t)
    db.session.commit()
    return jsonify({"id": t.id, "name": t.name, "year": t.year, "is_current": t.is_current}), 201


# ---------------------------------------------------------------
# Students
# ---------------------------------------------------------------
@admin_bp.route("/students", methods=["GET"])
@admin_required
def list_students():
    class_id = request.args.get("class_id", type=int)
    status = request.args.get("status")  # optional: ACTIVE, GRADUATED, TRANSFERRED, DROPPED
    q = Student.query
    if class_id:
        q = q.filter_by(class_id=class_id)
    if status:
        q = q.filter_by(status=status)
    return jsonify([
        {
            "id": s.id, "admission_no": s.admission_no, "full_name": s.full_name,
            "class_id": s.class_id, "class_name": s.school_class.name,
            "status": s.status,
            "subjects": [sub.id for sub in s.subjects]
        }
        for s in q.all()
    ])


@admin_bp.route("/students", methods=["POST"])
@admin_required
def create_student():
    data = request.json or {}
    admission_no = data.get("admission_no", "").strip()
    full_name = data.get("full_name", "").strip()
    class_id = data.get("class_id")
    subject_ids = data.get("subject_ids", [])

    if not admission_no or not full_name or not class_id:
        return jsonify({"error": "admission_no, full_name, class_id are required"}), 400

    student = Student(admission_no=admission_no, full_name=full_name, class_id=class_id)
    if subject_ids:
        student.subjects = Subject.query.filter(Subject.id.in_(subject_ids)).all()

    db.session.add(student)
    db.session.commit()
    return jsonify({"id": student.id, "admission_no": student.admission_no}), 201


@admin_bp.route("/students/<int:student_id>/subjects", methods=["PUT"])
@admin_required
def set_student_subjects(student_id):
    """Replace the full list of subjects a student offers."""
    student = Student.query.get_or_404(student_id)
    subject_ids = (request.json or {}).get("subject_ids", [])
    student.subjects = Subject.query.filter(Subject.id.in_(subject_ids)).all()
    db.session.commit()
    return jsonify({"id": student.id, "subjects": [s.id for s in student.subjects]})


@admin_bp.route("/students/promote", methods=["POST"])
@admin_required
def promote_students():
    """
    Year-end promotion. Two modes:

    1. Move up a class:
       { "from_class_id": 1, "to_class_id": 2 }
       -> promotes every ACTIVE student currently in class 1 to class 2.

    2. Graduate (e.g. S4 finishing school):
       { "from_class_id": 4, "graduate": true }
       -> marks every ACTIVE student in that class as GRADUATED instead
          of moving them (there's no "S5" to move them into).

    Repeaters: pass "exclude_student_ids": [...] with the IDs of students
    who should stay behind and repeat the class, or pass an explicit
    "student_ids": [...] list to promote only those (everyone else in
    the class is left untouched).

    This only updates students.class_id / status going forward. Every
    attendance and marks record already on file keeps the class it was
    actually recorded under, so past terms are unaffected.

    Every call logs a PromotionBatch + per-student before-state, so the
    response's batch_id can be passed to POST
    /students/promote/undo/<batch_id> to reverse it — but only while it's
    still the most recent batch (see undo_promotion() below).
    """
    data = request.json or {}
    from_class_id = data.get("from_class_id")
    to_class_id = data.get("to_class_id")
    graduate = bool(data.get("graduate", False))
    student_ids = data.get("student_ids")
    exclude_ids = set(data.get("exclude_student_ids", []))

    if not from_class_id:
        return jsonify({"error": "from_class_id is required"}), 400
    if not graduate and not to_class_id:
        return jsonify({"error": "to_class_id is required unless graduate=true"}), 400

    q = Student.query.filter_by(class_id=from_class_id, status="ACTIVE")
    if student_ids:
        q = q.filter(Student.id.in_(student_ids))
    students = [s for s in q.all() if s.id not in exclude_ids]

    batch = PromotionBatch(
        from_class_id=from_class_id,
        to_class_id=None if graduate else to_class_id,
        graduate=graduate,
        admin_user_id=g.user["user_id"],
    )
    db.session.add(batch)
    db.session.flush()  # get batch.id before we need it below

    for s in students:
        # Snapshot the before-state first — this is what undo restores.
        db.session.add(PromotionBatchStudent(
            batch_id=batch.id, student_id=s.id,
            previous_class_id=s.class_id, previous_status=s.status
        ))
        if graduate:
            s.status = "GRADUATED"
        else:
            s.class_id = to_class_id

    db.session.commit()
    return jsonify({
        "processed": len(students),
        "action": "graduated" if graduate else "promoted",
        "student_ids": [s.id for s in students],
        "batch_id": batch.id
    })


@admin_bp.route("/students/promote/undo/<int:batch_id>", methods=["POST"])
@admin_required
def undo_promotion(batch_id):
    """
    Reverts a promotion batch: every affected student's class_id/status
    goes back to exactly what it was right before that batch ran.

    Only the single most recent batch (by id, across all classes) can be
    undone, and only once. This isn't a general-purpose history browser —
    it's a narrow "oops, undo that" for the click you just made. Allowing
    older batches to be undone out of order risks unwinding a batch that a
    later promotion has already built on top of (e.g. promoting S2->S3,
    then S3->S4, then trying to undo the S2->S3 step alone).
    """
    latest = PromotionBatch.query.order_by(PromotionBatch.id.desc()).first()
    if not latest or latest.id != batch_id:
        return jsonify({
            "error": "Only the most recent promotion batch can be undone."
        }), 409
    if latest.undone:
        return jsonify({"error": "This batch was already undone."}), 409

    logs = PromotionBatchStudent.query.filter_by(batch_id=batch_id).all()
    reverted = 0
    for log in logs:
        student = Student.query.get(log.student_id)
        if student is None:
            continue  # student record was deleted since; nothing to restore
        student.class_id = log.previous_class_id
        student.status = log.previous_status
        reverted += 1

    latest.undone = True
    db.session.commit()
    return jsonify({"reverted": reverted, "batch_id": batch_id})


# ---------------------------------------------------------------
# Teachers (create user + teacher profile together)
# ---------------------------------------------------------------
@admin_bp.route("/teachers", methods=["GET"])
@admin_required
def list_teachers():
    teachers = Teacher.query.all()
    return jsonify([
        {
            "id": t.id, "staff_no": t.staff_no,
            "full_name": t.user.full_name, "username": t.user.username,
            "assignments": [
                {"subject_id": a.subject_id, "subject_name": a.subject.name,
                 "class_id": a.class_id, "class_name": a.school_class.name}
                for a in t.assignments
            ]
        }
        for t in teachers
    ])


@admin_bp.route("/teachers", methods=["POST"])
@admin_required
def create_teacher():
    data = request.json or {}
    username = data.get("username", "").strip()
    password = data.get("password", "")
    full_name = data.get("full_name", "").strip()
    staff_no = data.get("staff_no", "")

    if not username or not password or not full_name:
        return jsonify({"error": "username, password, full_name are required"}), 400
    if User.query.filter_by(username=username).first():
        return jsonify({"error": "username already exists"}), 409

    user = User(
        username=username,
        password_hash=generate_password_hash(password),
        full_name=full_name,
        role="TEACHER"
    )
    db.session.add(user)
    db.session.flush()  # get user.id before commit

    teacher = Teacher(user_id=user.id, staff_no=staff_no)
    db.session.add(teacher)
    db.session.commit()
    return jsonify({"id": teacher.id, "username": username, "full_name": full_name}), 201


# ---------------------------------------------------------------
# Teacher <-> Subject <-> Class assignments (the access-control table)
# ---------------------------------------------------------------
@admin_bp.route("/assignments", methods=["POST"])
@admin_required
def create_assignment():
    data = request.json or {}
    teacher_id = data.get("teacher_id")
    subject_id = data.get("subject_id")
    class_id = data.get("class_id")

    if not all([teacher_id, subject_id, class_id]):
        return jsonify({"error": "teacher_id, subject_id, class_id are required"}), 400

    existing = TeacherSubjectClass.query.filter_by(
        teacher_id=teacher_id, subject_id=subject_id, class_id=class_id
    ).first()
    if existing:
        return jsonify({"error": "This assignment already exists"}), 409

    assignment = TeacherSubjectClass(teacher_id=teacher_id, subject_id=subject_id, class_id=class_id)
    db.session.add(assignment)
    db.session.commit()
    return jsonify({"id": assignment.id}), 201


@admin_bp.route("/assignments/<int:assignment_id>", methods=["DELETE"])
@admin_required
def delete_assignment(assignment_id):
    a = TeacherSubjectClass.query.get_or_404(assignment_id)
    db.session.delete(a)
    db.session.commit()
    return jsonify({"deleted": assignment_id})


# ---------------------------------------------------------------
# Marks oversight
# ---------------------------------------------------------------
@admin_bp.route("/marks/<int:mark_id>/unlock", methods=["POST"])
@admin_required
def unlock_mark(mark_id):
    """Reverts a CONFIRMED mark back to DRAFT so the teacher can correct it."""
    from app.models import Mark
    mark = Mark.query.get_or_404(mark_id)
    mark.status = "DRAFT"
    mark.confirmed_at = None
    db.session.commit()
    return jsonify({"id": mark.id, "status": mark.status})
