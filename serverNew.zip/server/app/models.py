from datetime import datetime
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()


class User(db.Model):
    __tablename__ = "users"
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    full_name = db.Column(db.String(120), nullable=False)
    role = db.Column(db.Enum("ADMIN", "TEACHER", name="role_enum"), nullable=False)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    teacher = db.relationship("Teacher", backref="user", uselist=False)


class Teacher(db.Model):
    __tablename__ = "teachers"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), unique=True, nullable=False)
    staff_no = db.Column(db.String(30))

    assignments = db.relationship("TeacherSubjectClass", backref="teacher")


class SchoolClass(db.Model):
    __tablename__ = "classes"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(20), unique=True, nullable=False)


class Subject(db.Model):
    __tablename__ = "subjects"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), unique=True, nullable=False)
    code = db.Column(db.String(10), unique=True)


class Term(db.Model):
    __tablename__ = "terms"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(30), nullable=False)
    year = db.Column(db.Integer, nullable=False)
    is_current = db.Column(db.Boolean, default=False)


class Student(db.Model):
    __tablename__ = "students"
    id = db.Column(db.Integer, primary_key=True)
    admission_no = db.Column(db.String(30), unique=True, nullable=False)
    full_name = db.Column(db.String(120), nullable=False)
    class_id = db.Column(db.Integer, db.ForeignKey("classes.id"), nullable=False)
    status = db.Column(
        db.Enum("ACTIVE", "GRADUATED", "TRANSFERRED", "DROPPED", name="student_status"),
        default="ACTIVE", nullable=False
    )

    school_class = db.relationship("SchoolClass")
    subjects = db.relationship("Subject", secondary="student_subject", backref="students")


class PromotionBatch(db.Model):
    """One row per 'Run promotion' click. Lets the admin undo the most
    recent batch, since promotion has no other way to reverse itself."""
    __tablename__ = "promotion_batches"
    id = db.Column(db.Integer, primary_key=True)
    from_class_id = db.Column(db.Integer, db.ForeignKey("classes.id"), nullable=False)
    to_class_id = db.Column(db.Integer, db.ForeignKey("classes.id"), nullable=True)
    graduate = db.Column(db.Boolean, default=False)
    admin_user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    executed_at = db.Column(db.DateTime, default=datetime.utcnow)
    undone = db.Column(db.Boolean, default=False)


class PromotionBatchStudent(db.Model):
    """Per-student before-state for one PromotionBatch, so undo can put
    each student back exactly where they were."""
    __tablename__ = "promotion_batch_students"
    id = db.Column(db.Integer, primary_key=True)
    batch_id = db.Column(db.Integer, db.ForeignKey("promotion_batches.id"), nullable=False)
    student_id = db.Column(db.Integer, db.ForeignKey("students.id"), nullable=False)
    previous_class_id = db.Column(db.Integer, nullable=False)
    previous_status = db.Column(db.String(20), nullable=False)


student_subject = db.Table(
    "student_subject",
    db.Column("student_id", db.Integer, db.ForeignKey("students.id"), primary_key=True),
    db.Column("subject_id", db.Integer, db.ForeignKey("subjects.id"), primary_key=True),
)


class TeacherSubjectClass(db.Model):
    __tablename__ = "teacher_subject_class"
    id = db.Column(db.Integer, primary_key=True)
    teacher_id = db.Column(db.Integer, db.ForeignKey("teachers.id"), nullable=False)
    subject_id = db.Column(db.Integer, db.ForeignKey("subjects.id"), nullable=False)
    class_id = db.Column(db.Integer, db.ForeignKey("classes.id"), nullable=False)

    subject = db.relationship("Subject")
    school_class = db.relationship("SchoolClass")

    __table_args__ = (db.UniqueConstraint("teacher_id", "subject_id", "class_id"),)


class Attendance(db.Model):
    __tablename__ = "attendance"
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey("students.id"), nullable=False)
    subject_id = db.Column(db.Integer, db.ForeignKey("subjects.id"), nullable=False)
    class_id = db.Column(db.Integer, db.ForeignKey("classes.id"), nullable=False)
    teacher_id = db.Column(db.Integer, db.ForeignKey("teachers.id"), nullable=False)
    term_id = db.Column(db.Integer, db.ForeignKey("terms.id"), nullable=False)
    attendance_date = db.Column(db.Date, nullable=False)
    status = db.Column(db.Enum("PRESENT", "ABSENT", name="attendance_status"), nullable=False)
    recorded_at = db.Column(db.DateTime, default=datetime.utcnow)

    __table_args__ = (
        db.UniqueConstraint("student_id", "subject_id", "class_id", "attendance_date"),
    )


class Mark(db.Model):
    __tablename__ = "marks"
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey("students.id"), nullable=False)
    subject_id = db.Column(db.Integer, db.ForeignKey("subjects.id"), nullable=False)
    class_id = db.Column(db.Integer, db.ForeignKey("classes.id"), nullable=False)
    term_id = db.Column(db.Integer, db.ForeignKey("terms.id"), nullable=False)
    teacher_id = db.Column(db.Integer, db.ForeignKey("teachers.id"), nullable=False)
    exam_type = db.Column(db.Enum("BEGINNING", "MID", "END", name="exam_type_enum"), nullable=False)
    score = db.Column(db.Numeric(5, 2), nullable=False)
    status = db.Column(db.Enum("DRAFT", "CONFIRMED", name="mark_status"), default="DRAFT")
    confirmed_at = db.Column(db.DateTime, nullable=True)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    __table_args__ = (
        db.UniqueConstraint("student_id", "subject_id", "term_id", "exam_type"),
    )
